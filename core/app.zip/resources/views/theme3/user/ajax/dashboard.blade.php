@php
    $yourLinks = content('links.content');
@endphp

<!-- Wallet Card --><div style="background: #ffffff;"
     <div class="card"><div style="background: #000000;" class="img_hader">
        <div class="card-body"><div style="background: #000000;" class="img_hader">
            <div class="row">
                <div class="col-6">
                    <h6 class="mb-1 small-font text-start">Main Wallet</h6>
                    <h3 class="mb-1">{{ @$general->currency_sym }} {{ showAmount(@$user->balance) }}</h3>
                </div>
                <div class="col-6 text-end">
                    <h6 class="mb-1 small-font text-end">Bot Running Wallet</h6>
                    <h3 class="mb-1">{{ @$general->currency_sym }} {{ showAmount(@$user->trading_balance) }}</h3>
                </div>
            </div>

         
       </div>   

<br>
                   
               <div class="col-md-12">
                    <div class="new_service_outter_box d-flex justify-content-between">
                        <div class="new_service_item text-center">
                            <a href="{{route('user.usdt.index')}}">
                                 <img src="/imag/1716155406184 (1).png" alt="logo" style="width: 100px;
                                        margin-bottom: 5px;">
                            
                            
                            </a>
                        </div>
                         <div class="new_service_item text-center">
                            <a href="{{route('user.withdraw')}}">
                                 <img src="/imag/1716155731067 (1).png" alt="logo" style="width: 100px;
                                        margin-bottom: 5px;">
                            </a>
                        </div>
                         <div class="new_service_item text-center">
                            <a href="">
                                <img src="/imag/1716155694903 (1).png" alt="logo" style="width: 100px;
                                        margin-bottom: 5px;">
                            </a>
                        </div>
                    </div>


</div>
</div>

<!-- Stats -->
<div class="section">
    <div class="row mt-2">
        <div class="col-6"><div style="background: #0033cc;"
            <div class="stat-box p-1"><div style="background: #0033cc;"
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="65px" height="80px" src="/imag/photo1717170189 (7).jpeg" style="height:65px;">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Total Deposit</div>
                        <div class="value text-danger">{{@$general->site_currency}} {{ showAmount(@$totalDeposit)}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6"><div style="background: #0033cc;"
            <div class="stat-box p-1"><div style="background: #0033cc;"
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Total Withdraw</div>
                        <div class="value text-success">{{ @$general->site_currency }} {{ number_format($withdraw, 2)}}</div>
                    </div>
                    <div class="col-auto">
                        <img width="65px" height="50px" src="/imag/photo1717170189.jpeg" style="height:65px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-6 h-100"><div style="background: #134d00;"
            <div class="stat-box p-1"><div style="background: #134d00;"
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="65px" height="50px" src="/imag/photo1717170189 (3).jpeg" style="height:65px;">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Today Profit</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount($today['earning'])}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 h-100"><div style="background: #134d00;"
            <div class="stat-box p-1"><div style="background: #134d00;"
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Total Profit</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount($total['earning'])}}</div>
                    </div>
                    <div class="col-auto">
                        <img width="65px" height="50px" src="/imag/photo1717170189 (4).jpeg" style="height:65px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-6"><div style="background: #66004d;"
            <div class="stat-box p-1"><div style="background: #66004d;"
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="65px" height="50px" src="/imag/photo1717170189 (6).jpeg" style="height:65px;">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Reword Claim</div>
                        <div class="value">{{ @$general->site_currency }} {{ number_format($pendingInvest, 2)}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6"><div style="background: #66004d;"
            <div class="stat-box p-1"><div style="background: #66004d;"
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Refferal Earn</div>
                        <div class="value">{{ @$general->site_currency }} {{ number_format($commison, 2) }}</div>
                    </div>
                    <div class="col-auto">
                        <img width="65px" height="50px" src="/imag/photo1717170189 (5).jpeg" style="height:65px;">
                    </div>
                   
                </div>
            </div>
        </div>
       </div>

 <br>   <br>  <br> <br>   <br>  <br> <br>   <br>  <br> 

    {{-- <div class="row mt-2">
        <div class="col-6">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="40px" height="40px" style="opacity: 50%" src="{{asset('asset/images/icons-3d/pending-box.png')}}" alt="">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Pending Invest</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount($pendingInvest)}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Refferal Earn</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount($commison)}}</div>
                    </div>
                    <div class="col-auto">
                        <img width="40px" height="40px" style="opacity: 50%" src="https://cdn-icons-png.flaticon.com/128/5662/5662976.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div> --}}
</div>
<!-- * Stats -->




<!-- Stats -->
{{-- <div class="section">
    <div class="row mt-2">
        <div class="col-6">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/2/bank.png')}}" alt="">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Total Deposit</div>
                        <div class="value text-danger">{{@$general->currency_sym}} {{ showAmount(@$totalDeposit)}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Total Withdraw</div>
                        <div class="value text-success">{{@$general->currency_sym}} {{ showAmount(@$withdraw)}}</div>
                    </div>
                    <div class="col-auto">
                        <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/2/cashout.png')}}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-6 h-100">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/2/tholee.png')}}" alt="">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Total Invest</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount(@$totalInvest)}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 h-100">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Recent Invest</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount(@$currentInvest->amount)}}</div>
                    </div>
                    <div class="col-auto">
                        <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/2/transfer.png')}}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-6">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/2/pending.png')}}" alt="">
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">Pending Invest</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount($pendingInvest)}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="stat-box p-1">
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">Refferal Earn</div>
                        <div class="value">{{@$general->currency_sym}} {{ showAmount($commison)}}</div>
                    </div>
                    <div class="col-auto">
                        <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/2/mail-money.png')}}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> --}}
<!-- * Stats -->
<!-- Account Options -->
{{-- <div class="section mt-3">
    <div class="section-heading">
        <h2 class="title">Account Options</h2>
    </div>
    <div class="row mt-2">
        <a class="col-3 text-center profileSettingBtn" href="{{route('user.profile')}}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/men-dollar.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Profile</p>
        </a>
        <a class="col-3 text-center addressSettingBtn" href="{{route('user.address')}}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/dollar-location.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Address</p>
        </a>
        <a class="col-3 text-center passwordChangeBtn" href="{{route('user.change.password')}}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/lock.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Password</p>
        </a>
    </div>
</div> --}}

<!-- Logs -->
{{-- <div class="section mt-3">
    <div class="section-heading">
        <h2 class="title">All Logs</h2>
    </div>
    <div class="row mt-2">
        <a class="col-3 text-center depositLogBtn" href="{{ route('user.deposit.log') }}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/logs.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Deposit</p>
        </a>
        <a class="col-3 text-center withdrawLogBtn" href="{{ route('user.withdraw.all') }}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/logs-2.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Withdraw</p>
        </a>
        <a class="col-3 text-center investLogBtn" href="{{ route('user.invest.log') }}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/logs-5.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Invest</p>
        </a>
        <a class="col-3 text-center interestLogBtn" href="{{ route('user.interest.log') }}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/logs-4.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Interest</p>
        </a>
        <a class="col-3 text-center transactionLogBtn" href="{{ route('user.transaction.log') }}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/logs-6.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Transaction</p>
        </a>
        <a class="col-3 text-center commisionLogBtn" href="{{ route('user.commision') }}">
            <div class="card">
                <div class="card-body p-1">
                    <img width="50px" height="50px" src="{{asset('asset/images/2d-icon/3/logs-7.png')}}" alt="">
                </div>
            </div>
            <p class="mb-0" style="font-size: 12px;">Referral</p>
        </a>
    </div>
</div> --}}



<!-- Dialog Basic -->
<div class="modal fade dialogbox" id="signoutAlert" data-bs-backdrop="static" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Are you sure?</h5>
            </div>
            <div class="modal-footer">
                <div class="btn-inline">
                    <a href="#" class="btn btn-text-secondary" data-bs-dismiss="modal">CANCEL</a>
                    <a href="{{route('user.logout')}}" class="btn btn-text-primary">YES</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- * Dialog Basic -->
<br>


@push('script')
<script>
    $('.copytext').on('click', function() {
        var copyText = document.getElementById("referralURL");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        document.execCommand("copy");
        notifyMsg("Copied: " + copyText.value,'success');
        notifyMsg("Copy Success!",'success')
    });
</script>
@endpush
