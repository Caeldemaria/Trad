@extends(template() . 'layout.master2')

@section('content2')

    <div style="background: #ffffff;">
        <div class="card">
            <div style="background: #000000;" class="img_hader">
                <!-- Stats -->
                <div class="section">
                    <br>
                    <div class="text_canter_man">
                        <h3 style="text-align: center;font-weight: bold;font-size: 25px;color: #c9d6d7;">Rank &amp;Reward</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .r_box {
            display: flex;
            background: #1663c5;
            margin-bottom: 5px;
            padding: 5px;
            border-radius: 7px;
            align-items: center;
            justify-content: space-between;
        }
        .r_box p {
            margin: 0;
            font-size: 11px;
            color: #fff;
            line-height: 1.5;
        }
        a.clm {
    background: #fff;
    color: #000;
    height: 40px;
    width: 55px;
    line-height: 40px;
    text-align: center;
    border-radius: 5px;
    font-weight: bolder;
    font-size: 13px;
}
    </style>


    <div class="section" style="margin-top:15px;">
        <div class="row">

            @foreach(\App\Models\Reward::get() as $key=>$element)
            <div class="col-6" style="padding-left: 2px;padding-right: 2px;">
                <div class="r_box"  style="@if($key % 2 == 0) background: #003cff @else blue @endif">
                    <div>
                        <p>Rank: <span>{{$element->name}}</span></p>
                        <p>Direct: <span>{{$element->size}}</span></p>
                        <p>Total Team: <span>{{teamSize(auth()->id(), 1)+teamSize(auth()->id(), 2)+teamSize(auth()->id(), 3)}}</span></p>
                        <p>Bonus: <span>{{ number_format($element->bonus, 2) . ' ' . $general->site_currency }}</span></p>
                    </div>
                    <div>
                        <a href="{{route('user.clm', $element->id)}}" class="clm">Claim</a>
                    </div>
                </div>
            </div>
            @endforeach
              <!-- Wallet Card -->
              </div>
              </div>
    <div style="background: #ffffff;">
        <div class="card">
            <div style="background: #000000;" class="img_hader">
                
                <!-- Stats -->
                <div class="section">
                    <style>
                        * {
                            color: #adc9d4;
                        }

                        #customers {
                            font-family: Arial, Helvetica, sans-serif;
                            border-collapse: collapse;
                            width: 100%;
                            border: solid 1px #c50707;
                        }

                        #customers td, #customers th {
                            padding: 8px;
                        }

                        #customers td, #customers th {
                            padding: 8px;
                            display: flex;
                            align-items: center;
                        }

                        #customers th {
                            padding-top: 12px;
                            padding-bottom: 12px;
                            text-align: left;
                            font-size: 13px;
                            color: rgb(255 255 255);
                        }

                        #border_solid {
                            display: flex;
                            align-items: center;
                            flex-wrap: nowrap;
                            justify-content: space-between;
                        }

                        #clicme_btn {
                            border: none;
                            padding: 7px;
                            border-radius: 6px;
                            background: #1f2e3a;
                            color: white;
                            font-weight: bold;
                        }
                    </style>
                    <br>

                    <div class="text_canter_man">
                        <h3 style="text-align: center;font-weight: bold;font-size: 25px;color: #c9d6d7;"></h3>
                    </div>
                    <div class="tr_ta_body">
                        <table id="customers">
                            <tr id="border_solid" style="border: solid 1px #2b72b6;">
                                <th></th>
                                <th>Leader Salary Rank</th>
                               <th></th>
                            </tr>
                            <!----ADD Laravel Row----->

                        <style>

                            #id_tr th {
                                border: solid 1px #4ca550;
                                color: #adb6bd;
                                text-align: center;
                                font-size: 12px;

                            
                        </style>
                        <table id="id_tr">
                            <tr>
                                

                                <th>
                                    5 Glorious Rank Marvelous Your Direct Refer Total Team - 600 Team Deposit-100k
                                </th>

                                <th>
                                    Bonus - 3000$ Monthly Salary- 1000$ (3 Month) Incentive - 3 Day, 7 Day & Monthly

                                </th>
                            </tr>
                        </table>
                        
                                      <!-- Wallet Card -->
              </div>
              </div>
    <div style="background: #ffffff;">
        <div class="card">
            <div style="background: #000000;" class="img_hader">
                
                <!-- Stats -->
                <div class="section">
                    <style>
                        * {
                            color: #adc9d4;
                        }

                        #customers {
                            font-family: Arial, Helvetica, sans-serif;
                            border-collapse: collapse;
                            width: 100%;
                            border: solid 1px #c50707;
                        }

                        #customers td, #customers th {
                            padding: 8px;
                        }

                        #customers td, #customers th {
                            padding: 8px;
                            display: flex;
                            align-items: center;
                        }

                        #customers th {
                            padding-top: 12px;
                            padding-bottom: 12px;
                            text-align: left;
                            font-size: 13px;
                            color: rgb(255 255 255);
                        }

                        #border_solid {
                            display: flex;
                            align-items: center;
                            flex-wrap: nowrap;
                            justify-content: space-between;
                        }

                        #clicme_btn {
                            border: none;
                            padding: 7px;
                            border-radius: 6px;
                            background: #1f2e3a;
                            color: white;
                            font-weight: bold;
                        }
                    </style>
                    <br>

                    <div class="text_canter_man">
                        <h3 style="text-align: center;font-weight: bold;font-size: 25px;color: #c9d6d7;"></h3>
                    </div>
                    <div class="tr_ta_body">
                        <table id="customers">
                            <tr id="border_solid" style="border: solid 1px #2b72b6;">
                                <th></th>
                                <th>Top Leader Salary Rank</th>
                               <th></th>
                            </tr>
                            <!----ADD Laravel Row----->

                        <style>

                            #id_tr th {
                                border: solid 1px #4ca550;
                                color: #adb6bd;
                                text-align: center;
                                font-size: 12px;

                            
                        </style>
                        <table id="id_tr">
                            <tr>
                                

                                <th>
                                    5 Glorious Rank Marvelous Your Direct Refer Total Team - 600 Team Deposit-100k
                                </th>

                                <th>
                                    Bonus - 3000$ Monthly Salary- 1000$ (3 Month) Incentive - 3 Day, 7 Day & Monthly

                                </th>
                            </tr>
                        </table>
       
  
    <!-- Wallet Card -->
    </div> </div> </div>
    <div style="background: #ffffff;">
        <div class="card">
            <div style="background: #000000;" class="img_hader">
                
                <!-- Stats -->
                <div class="section">
                    <style>
                        * {
                            color: #adc9d4;
                        }

                        #customers {
                            font-family: Arial, Helvetica, sans-serif;
                            border-collapse: collapse;
                            width: 100%;
                            border: solid 1px #c50707;
                        }

                        #customers td, #customers th {
                            padding: 8px;
                        }

                        #customers td, #customers th {
                            padding: 8px;
                            display: flex;
                            align-items: center;
                        }

                        #customers th {
                            padding-top: 12px;
                            padding-bottom: 12px;
                            text-align: left;
                            font-size: 13px;
                            color: rgb(255 255 255);
                        }

                        #border_solid {
                            display: flex;
                            align-items: center;
                            flex-wrap: nowrap;
                            justify-content: space-between;
                        }

                        #clicme_btn {
                            border: none;
                            padding: 7px;
                            border-radius: 6px;
                            background: #1f2e3a;
                            color: white;
                            font-weight: bold;
                        }
                    </style>
                    <br>

                    <div class="text_canter_man">
                        <h3 style="text-align: center;font-weight: bold;font-size: 25px;color: #c9d6d7;"></h3>
                    </div>
                    <div class="tr_ta_body">
                        <table id="customers">
                            <tr id="border_solid" style="border: solid 1px #2b72b6;">
                                <th>Balance</th>
                                <th>Commision</th>
                                <th>Balance</th>
                                <th>Profit</th>
                               <th></th>
                            </tr>

                            <!----ADD Laravel Row----->

                            <tr id="border_solid">
                                <td>100-300</td>
                                <td>20%
                                    
                                </td>
                                <td>300 {{ @$general->currency_sym }}
                                    
                                </td>
                                <td>1-2.10%</td>
                                <td>
                                   


                            <tr id="border_solid">
                                <td>400-800</td>
                                <td>22%
                                   
                                </td>
                                <td>800 {{ @$general->currency_sym }}
                                    
                                </td>
                                <td>1-2.20%</td>
                                <td>
                                   


                            <tr id="border_solid">
                                <td>1000-1400</td>
                                <td>24%
                                  
                                </td>
                                <td>1400 {{ @$general->currency_sym }}
                                    
                                </td>
                                <td>1-2.30%</td>
                                <td>
                                   

                            <tr id="border_solid">
                                <td>1600-2400</td>
                                <td>26%
                                    
                                </td>
                                <td>2400 {{ @$general->currency_sym }}
                                    
                                </td>
                                <td>1-2.40%</td>
                                <td>
                                   

                            <tr id="border_solid">
                                <td>2600-3400</td>
                                <td>29%
                                    
                                </td>
                                <td>3400 {{ @$general->currency_sym }}
                                    
                                </td>
                                <td>1-2.50%</td>
                                <td>
                                   


                            <tr id="border_solid">
                                <td>3600-5000</td>
                                <td>32%
                                    
                                </td>
                                <td>5000 {{ @$general->currency_sym }}
                                    
                                </td>
                                <td>1-2.60%</td>
                                <td>
                                   
                    </div>
                </div>
            </div>
        </div>
  <br>
   
@endsection



