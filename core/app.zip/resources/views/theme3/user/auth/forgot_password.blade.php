@extends('theme3.layout.auth')
@section('content')
    @include('theme3.user.auth.ajax.forgot_password')
@endsection
