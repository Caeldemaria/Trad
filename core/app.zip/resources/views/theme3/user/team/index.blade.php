
@extends(template().'layout.master2')
<div style="background: ;"
@section('content2')<div style="background: #ffffff;"
 </div>
 <br>
    <div class="container">
        <div class="card mb-2"><div style="background: #0033cc;"
            <div class="card-body pb-0 pt-1">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label class="form-label mb-0">Referral Link</label>
                            <div class="input-group">
                                <input type="text" name="key" value="{{ route('user.register', [Auth::user()->ref_id]) }}" class="form-control form-control-sm" id="referralURL" readonly="">
                                <a class="input-group-text btn btn-gr-red px-3 cursor-pointer copytext" id="copyBoard">
                                    <i class="fas fa-copy"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




    <div class="card mt-2"><div style="background: #ffffff;"
        <div class="card-body text-center">
            <h3 class="pb-2 mb-1 border-bottom"><span class="text-black">Total Team <br>{{teamSize($user->id, 1)+teamSize($user->id, 2)+teamSize($user->id, 3)}}</h3>
            <div class="row justify-content-center">
                <div class="col-3 d-inline-block text-truncate px-1 mb-1">
                    <a class="btn btn-primary btn-sm w-100 logNav transactionLogBtn" id="logNavTransaction" href="Total Earn">Total Earn</a>
                </div>
                <div class="col-3 d-inline-block text-truncate px-1 mb-1">
                    <a class="btn btn-primary btn-sm w-100 logNav depositLogBtn" id="logNavDeposit" href="#" >{{@$general->currency_sym}}{{ showAmount($commison)}}</a>
                </div>
                <div class="col-3 d-inline-block text-truncate px-1 mb-1">
                    <a class="btn btn-primary btn-sm w-100 logNav withdrawLogBtn" id="logNavWithdraw" href="#">Work Team</a>
                </div>
                {{-- <div class="col-3 d-inline-block text-truncate px-1 mb-1">
                    <a class="btn btn-primary btn-sm w-100 logNav investLogBtn" id="logNavInvest" href="#">{{depoTeamSize($user->id, 1)+depoTeamSize($user->id, 2)+depoTeamSize($user->id, 3)}}</a>
                </div>
                <div class="col-3 d-inline-block text-truncate px-1 mb-1">
                    <a class="btn btn-primary btn-sm w-100 logNav interestLogBtn" id="logNavInterest" href="#">Interest</a>
                </div> --}}
                <div class="col-3 d-inline-block text-truncate px-1 mb-1">
                    <a class="btn btn-primary btn-sm w-100 logNav commisionLogBtn" id="logNavReferral" href="#">{{depoTeamSize($user->id, 1)+depoTeamSize($user->id, 2)+depoTeamSize($user->id, 3)}}</a>
                </div>
            </div>
        </div>
    </div>
</div>

         <a href='/commision' <div> <img src="/imag/photo1717007600.jpeg" style="height:200px;"></div>
        <div class="card mt-2"><div style="background: #ffffff;"
            <div class="card-body"><div style="background: #ffffff;"
                <div class="row justify-content-center">
                    @for($i=1; $i<=3; $i++)
                        <div class="col-4 px-1">
                            <a class="btn btn-gr-red btn-sm border-0 w-100 customLink @if($i == $lev) disabled @endif"  href="{{route('user.team', $i)}}">Lev{{$i}}({{teamSize($user->id, $i)}})</a>
                        </div>
                    @endfor
                </div>
            </div>
        </div>

        <div class="my-3"><div style="background: #ffffff;"
            {{showUserLevel($user->id, $lev)}}
        </div>

    </div>



@endsection

@push('script')
<script>
    $('.copytext').on('click', function() {
        var copyText = document.getElementById("referralURL");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        document.execCommand("copy");
        notifyMsg("Copied: " + copyText.value,'success');
        notifyMsg("Copy Success!",'success')
    });
</script>
@endpush
<div style="background: #ffffff;"
