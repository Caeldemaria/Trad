
@php
    $sliding_banner = element('sliding_banner.element');
    $notice = content('notice.content');
    $yourLinks = content('links.content');
@endphp
<div style="background: #000000;"

{{-- <div id="sliderBody">
    <!-- Sliding Banner -->
    <div class="section wallet-card-section pt-1">
        <div id="owl-demo" class="owl-carousel owl-theme mt-2">
            @foreach ($sliding_banner as $slid)
                <div class="item">
                    <img class="rounded-10px" src="{{asset('asset/theme3/images/sliding_banner/'. $slid->data->image)}}" alt="">
                </div>
            @endforeach
        </div>
    </div>
    <!-- Sliding Banner -->
</div> --}}
 

    <div class="card"><div style="background: #000000;" 
        <div class="card-body"> 
                      <div class="row">
                <div class="col-6">
                    <a href="{{route('user.usdt.index')}}"  <button class="btn btn-col-md-12" style="background-color: #fdc708 !important;">Main Wallet {{ number_format(auth()->check() ? auth()->user()->balance : 0, 2) }}{{ @$general->currency_sym }} </a></h3>
                </div>
                <div class="col-6 text-end">
                <a href="{{route('user.usdt.index')}}"  <button class="btn btn-col-md-12" style="background-color: #fdc708 !important;">Deposit</a>
                
            </div>
          
 </div>

</div>  

<div id="sliderBody">
<div class="section wallet-card-section pt-1">
    <div id="sliderCarosel" class="carousel slide" data-bs-ride="carousel">

        <div class="carousel-inner rounded-20px shadow-sm">

            @php $i=0; @endphp
            @forelse($sliding_banner as $item)
                @php
                    $actives = '';
                @endphp

                @if ($i == 0)
                    @php $actives = 'active';@endphp
                @endif
                @php $i=$i+1; @endphp

                <div class="carousel-item {{$actives}}">
                    
                </div>
 
            @empty
            @endforelse

      
        <button class="carousel-control-prev" type="button" data-bs-target="#sliderCarosel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#sliderCarosel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        </a>
    </div>
</div>
</div>
    <!-- Icon Card -->
    <div class="row">
        <a href="{{route('user.team', 1)}}" class="col-3 text-center">
            <div class="card rounded-circle text-center" style="height: 60px; width: 60px; margin:auto;">
                <div class="card-body p-0">
                    <img class="p-1" src="/imag/CC_20240528_192914.png" alt="">
                </div>
            </div>
            <span class="small-font">My Team</span>
        </a>
        <a href="{{@$yourLinks->data->telegram}}" class="col-3 text-center">
            <div class="card rounded-circle text-center" style="height: 60px; width: 60px; margin:auto;">
                <div class="card-body p-0">
                    <img class="p-1" src="/imag/Telegram_2019_Logo.svg.png" alt="">
                </div>
            </div>
            <span class="small-font">Telegram</span>
        </a>
        <a href="{{@$yourLinks->data->apps}}" class="col-3 text-center">
            <div class="card rounded-circle text-center" style="height: 60px; width: 60px; margin:auto;">
                <div class="card-body p-0">
                    <img class="p-1" src="/imag/CC_20240528_192407.png" alt="">
                </div>
            </div>
            <span class="small-font">App Downloed</span>
        </a>
        <a href="{{ route('user.withdraw.setting.usdt') }}" class="col-3 text-center">
            <div class="card rounded-circle text-center" style="height: 60px; width: 60px; margin:auto;">
                <div class="card-body p-0">
                    <img class="p-1" src="/imag/CC_20240528_192256.png" alt="">
                </div>
            </div>
            <span class="small-font">Bank set</span>
        </a>
    </div>


            {{-- <div class="row">
                <a class="col-3 text-center customLink" href="{{route('user.usdt.index')}}">
                    <img width="45px" src="{{asset('asset/images/site-icons/deposit-2.png')}}">
                    <div class="small-font">Deposit</div>
                </a>
                <a class="col-3 text-center customLink" href="{{route('user.withdraw')}}">
                    <img width="45px" src="{{asset('asset/images/site-icons/withdraw-2.png')}}">
                    <div class="small-font">Withdraw</div>
                </a>
                <a class="col-3 text-center transactionLogBtn" href="javascript:void(0)">
                    <img width="45px" src="{{asset('asset/images/site-icons/record.png')}}">
                    <div class="small-font">Records</div>
                </a>
                <a class="col-3 text-center profileSettingBtn" href="javascript:void(0)">
                    <img width="45px" src="{{asset('asset/images/site-icons/account-manage.png')}}">
                    <div class="small-font">Account</div>
                </a>
            </div> --}}
         </div>
    <!-- Card 2 -->
<div class="container">
    <!-- Scroling Notice -->
     <div class="container mb-3">
        <div class="card mt-2">
            <div class="card-body py-0">
                <div class="row align-items-center">
                    <div class="bg-scroll-light col-auto px-0" style="border-radius: 20px; margin-left: -8px;">
                       {{-- <img src="https://cdn-icons-png.flaticon.com/128/7261/7261282.png" width="20px" height="20px" alt="">--}}
                         <img src="{{asset('asset/images/icons-3d/mike.png')}}" width="20px" height="20px" alt=""> 
                    </div>
                    <div class="col px-0 pt-1">
                       <marquee style="background: #330000;
    width: 100%;
    color: red;
    margin-left: 5px;" behavior="scroll" direction="left">
                         {{@$notice->data->title}} {{@$notice->data->title}}
</marquee> 	
                    </div>
                </div>
            </div>
        </div>
    </div>   
</div> 
    <!----------Developer JIBON---------->
    <div style="background: #000000;" class="img_hader">
<div class="section">
    <div class="row mt-2"> 
        <div class="col-6"><div style="background: #000000;" 
            <div class="stat-box p-1"><div style="background: #000000;" 
                <div class="row align-items-center">
                    <div class="col-auto">
                        
                    </div><div style="background: #000000;" 
                    <div class="col ps-0 text-end"><div style="background: #000000;" 
                        <div class="title">All Trading Volume</div><div style="background: #000000;" 
                       <marquee <div class="value text-danger">1000234457987K</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6"><div style="background: #000000;" 
            <div class="stat-box p-1"><div style="background: #000000;" 
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">All Total User</div>
                        <div class="value text-success">1001232134.00k</div>
                    </div>
                    <div class="col-auto">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-6 h-100"><div style="background: #000000;" 
            <div class="stat-box p-1"><div style="background: #000000;" 
                <div class="row align-items-center">
                    <div class="col-auto">
                        
                    </div>
                    <div class="col ps-0 text-end">
                        <div class="title">All Total Deposit</div>
                        <div class="value text-success">100325654.00k</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6 h-100"><div style="background: #000000;" 
            <div class="stat-box p-1"><div style="background: #000000;" 
                <div class="row align-items-center">
                    <div class="col pe-0 text-start">
                        <div class="title">All Total Withdraw</div>
                        <div class="value text-danger">100000065.00k</div>
                    </div>
                    <div class="col-auto">
                        
                    </div>
                </div>
            </div>
        </div>
   </div></div><br>
   <a href='https://extmnetwork.blogspot.com/?m=1' </div><span style="margin-left: 4%;"><img src="/imag/IMG_20240528_145509_712.jpg" style="height:33px;"> 
   
{{-- <div id="sliderBody
 <div>
  <!-- Sliding Banner -->
    <div class="section wallet-card-section pt-1">
        <div id="owl-demo" class="owl-carousel owl-theme mt-2">
            @foreach ($sliding_banner as $slid)
                <div class="item">
                    <img class="rounded-20px" src="{{asset('asset/theme3/images/sliding_banner/'. $slid->data->image)}}" alt="">
                </div>
            @endforeach
        </div>
    </div>
    <!-- Sliding Banner -->

</div> --}}
<div class="section wallet-card-section pt-1">
    <div id="sliderCarosel" class="carousel slide" data-bs-ride="carousel">

        <div class="carousel-inner rounded-20px shadow-sm">

            @php $i=0; @endphp
            @forelse($sliding_banner as $item)
                @php
                    $actives = '';
                @endphp

                @if ($i == 0)
                    @php $actives = 'active';@endphp
                @endif
                @php $i=$i+1; @endphp

                <div> <img src="/imag/logobanner_orig.gif" style="height:220px;"></div>

            @empty
            @endforelse

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#sliderCarosel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#sliderCarosel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        </a>
    </div>
</div><br>
</div>
            
            
            
            
            
            
            
            
            
            
            <style>
.container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
}

.stat-card {
    display: flex;
    align-items: center;
    border-radius: 8px;
    padding: 22px;
    transition: all 0.3s ease-in-out;
}

.stat-card__icon {
    flex: 0 0 auto;
    margin-right: 15px;
    font-size: 1rem;
    color: #fff;
}

.stat-card__content {
    flex: 1 1 auto;
}

.stat-card__content .title {
    font-size: 1rem;
    font-weight: 600;
    color: #ffffffcf;
    margin: 0 0 5px;
}

.stat-card__content .numbers {
    font-size: 13px;
    font-weight: 700;
    color: #007bff;
}

            </style>
<!-- TradingView Widget END -->

{{-- @if ($sections->sections != null)
    @foreach ($sections->sections as $sections)
        @include(template().'sections.' . $sections)
    @endforeach
@endif --}}


<!-- mt-2 gaph -->
{{-- <div class="mt-2"></div>


<div class="modal fade" id="calculationModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{ __('Profit calculate') }}</h5>
                <button type="button" class="close btn btn-warning" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="text-light">×</span>
                </button>
            </div>
            <div class="modal-body" id="profit">


            </div>
        </div>
    </div>
</div> --}}


