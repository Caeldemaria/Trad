<style>
    .dashboard-main {
        background: linear-gradient(180deg, rgb(57 213 255) 0%, rgb(116 202 255) 9%, rgba(229, 234, 240, 1) 35%);
        background-attachment: fixed !important;
    }
    .bg-primary {
        background-image: linear-gradient(to bottom, #3994ff 0, #6fcdfe 100%) !important;
    }
    .action-button {
        background: #0d9cfda6 !important;
    }
    .btn-pink-light, .bg-pink-light {
        background-image: linear-gradient(to bottom, #28c4f6 0, #c6fffc 100%) !important;
    }
    .btn-pink-light-alt, .btn-pink-light:hover {
        background-image: linear-gradient(to top, #28c4f6 0, #c6fffc 100%) !important;
    }
    .btn-pink-light-alt:hover {
        background-image: linear-gradient(to bottom, #28c4f6 0, #c6fffc 100%) !important;
    }
    .bg-pink-light-alt {
        background-image: linear-gradient(to top, #28c4f6 0, #c6fffc 100%) !important;
    }
</style>
